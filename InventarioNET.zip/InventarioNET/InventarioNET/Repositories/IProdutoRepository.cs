﻿using InventarioNET.Models;

namespace InventarioNET.Repositories
{
    public interface IProdutoRepository : IGenericRepository<Produto>
    {
    }
}
