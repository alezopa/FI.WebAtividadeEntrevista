﻿using System.Data.Entity;

namespace Mvc5_Modal.Models
{
    public class ClienteDbContext : DbContext
    {
        public DbSet<Cliente> Clientes { get; set; }
    }
}